Taruh gambar janken di sini: gunting.png, batu.png, kertas.png
Jika file tidak ada, aplikasi otomatis memakai placeholder SVG.
